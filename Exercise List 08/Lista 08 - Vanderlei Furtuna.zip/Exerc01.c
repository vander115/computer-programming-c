#include <stdio.h>

// Autor: José Vanderlei Furtuna Tomé - 554397

int main()
{

  printf("O tipo CHAR possuiu %d bytes", sizeof(char));
  printf("O tipo INT possuiu %d bytes", sizeof(int));
  printf("O tipo FLOAT possuiu %d bytes", sizeof(float));
  printf("O tipo DOUBLE possuiu %d bytes", sizeof(double));

  return 0;
}