#include <stdio.h>

int main()
{

  int i = 0;

  while (i <= 255)
  {
    printf("%3d\n", i);
    i++;
  }

  return 0;
}